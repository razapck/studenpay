export enum TransactionType {
  DEPOSIT = 'DEPOT',
  TRANSFER = 'TRANSFERT',
  PAYMENT = 'PAIEMENT'
}

export enum TransactionStatus {
  PENDING = 'EN-COURS',
  COMPLETED = 'COMPLETE',
  FAILED = 'ECHOUE'
}

export interface User {
  id: string; // uuid
  nom: string; // text not null
  email: string; // text not null
  created_at: string; // timestamp
  type?: string | null; // text null
  adresse?: string | null; // text null
  num_CIN?: string | null; // text null ("num_CIN")
  role?: string | null; // text null
  type_utilisateur?: string | null; // text null
  passwd?: number | null; // integer null (anciennement code_utilisateur)
}

export interface Wallet {
  id: string;
  userId: string;
  balance: number;
  currency: string;
}

export interface Transaction {
  id: string;
  sourceWalletId?: string; // Null if deposit
  destinationWalletId?: string; // Null if withdrawal (not implemented here)
  amount: number;
  type: TransactionType;
  status: TransactionStatus;
  createdAt: string;
  description: string;
}

export interface ApiError {
  message: string;
}